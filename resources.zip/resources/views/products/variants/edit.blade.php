@extends('layouts.app')

@section('title', 'Modifier la variante : '.$product->name)

@section('content')
    <form method="POST" action="{{ route('products.variants.update', [$product, $variant]) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('products.variants._form', ['product' => $product, 'variant' => $variant])
    </form>
@endsection
