@extends('layouts.app')

@section('title', 'Nouvelle catégorie')

@section('content')
    <form method="POST" action="{{ route('categories.store') }}" enctype="multipart/form-data" class="max-w-xl rounded-xl bg-white p-6 shadow">
        @csrf
        @include('categories._form', ['category' => null])
    </form>
@endsection
