@extends('layouts.app')

@section('title', 'Modifier la catégorie')

@section('content')
    <form method="POST" action="{{ route('categories.update', $category) }}" enctype="multipart/form-data" class="max-w-xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('categories._form', ['category' => $category])
    </form>
@endsection
