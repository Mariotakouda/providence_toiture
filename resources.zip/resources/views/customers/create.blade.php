@extends('layouts.app')

@section('title', 'Nouveau client')

@section('content')
    <form method="POST" action="{{ route('customers.store') }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @include('customers._form', ['customer' => null])
    </form>
@endsection
