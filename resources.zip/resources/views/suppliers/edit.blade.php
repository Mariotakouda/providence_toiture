@extends('layouts.app')

@section('title', 'Modifier le fournisseur')

@section('content')
    <form method="POST" action="{{ route('suppliers.update', $supplier) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('suppliers._form', ['supplier' => $supplier])
    </form>
@endsection
