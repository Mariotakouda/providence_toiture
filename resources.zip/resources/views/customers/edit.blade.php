@extends('layouts.app')

@section('title', 'Modifier le client')

@section('content')
    <form method="POST" action="{{ route('customers.update', $customer) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('customers._form', ['customer' => $customer])
    </form>
@endsection
