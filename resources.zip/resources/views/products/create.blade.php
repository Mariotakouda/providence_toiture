@extends('layouts.app')

@section('title', 'Nouveau produit')

@section('content')
    <form method="POST" action="{{ route('products.store') }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @include('products._form', ['product' => null])
    </form>
@endsection
