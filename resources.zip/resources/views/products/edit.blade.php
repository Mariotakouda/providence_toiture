@extends('layouts.app')

@section('title', 'Modifier le produit')

@section('content')
    <form method="POST" action="{{ route('products.update', $product) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('products._form', ['product' => $product])
    </form>
@endsection
