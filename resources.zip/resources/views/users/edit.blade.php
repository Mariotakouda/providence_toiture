@extends('layouts.app')

@section('title', 'Modifier l’utilisateur')

@section('content')
    <form method="POST" action="{{ route('users.update', $user) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @method('PUT')
        @include('users._form', ['user' => $user, 'currentRole' => $currentRole])
    </form>
@endsection
