@extends('layouts.app')

@section('title', 'Nouvelle variante : '.$product->name)

@section('content')
    <form method="POST" action="{{ route('products.variants.store', $product) }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @include('products.variants._form', ['product' => $product, 'variant' => null])
    </form>
@endsection
