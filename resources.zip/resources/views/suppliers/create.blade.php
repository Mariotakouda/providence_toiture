@extends('layouts.app')

@section('title', 'Nouveau fournisseur')

@section('content')
    <form method="POST" action="{{ route('suppliers.store') }}" class="max-w-3xl rounded-xl bg-white p-6 shadow">
        @csrf
        @include('suppliers._form', ['supplier' => null])
    </form>
@endsection
